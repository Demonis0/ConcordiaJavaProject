package fr.demonis.javaproject.Objects;

public class Billing {
}
